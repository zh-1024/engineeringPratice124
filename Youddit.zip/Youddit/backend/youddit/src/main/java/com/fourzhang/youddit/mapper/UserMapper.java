package com.fourzhang.youddit.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fourzhang.youddit.entity.User;


public interface UserMapper extends BaseMapper<User> {
    
}
